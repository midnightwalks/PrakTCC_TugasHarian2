import { where } from "sequelize";
import User from "../model/UserModel.js";

//Function mengambil semua data user dari db

export const getUsers = async(req, res)=>{
    try {
        const response = await User.findAll();
        res.status(200).json(response);
    } catch (error) {
        console.log(error.message);
    }
}

// CREATE
export const createUser = async(req, res)=>{
    try {
        await User.create(req.body);
        res.status(201).json({msg: "User berhasil ditambah"});
    } catch (error) {
        console.log(error.message);
    }
}

// UPDATE
export const updateUser = async (req, res) => {
    try {
        const inputData = req.body //buat nyimpen input 
        const id = req.params.id // buat nyimpen id

        await User.update(inputData, {
            where: {
                id: id
            }
        });
            res.status(200).json({
                msg: "berhasil update data",
            })
    } catch (error) {
        console.log(error.message)
    }
}

// DELETE
export const deleteUser = async (req, res) => {
    try {
        const id = req.params.id // buat nyimpen id 
        await User.destroy({
            where: {
                id,
            },
        });
        res.status(200).json({
            message: "data berhasil dihapus",
        });
    } catch (error) {
        console.log(error.message)
    }
};

