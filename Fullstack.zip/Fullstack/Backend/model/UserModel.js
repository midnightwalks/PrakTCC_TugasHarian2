import { Sequelize } from "sequelize";
import db from "../config/Database.js";

const user = db.define('users', {
    name:{type: Sequelize.STRING, allowNull:true},
    email: Sequelize.STRING,
    gender: Sequelize.STRING}
    ,{
        freezeTableName:true,
        //timestamps: false
        createdAt: 'Tanggal_dibuat',
        updatedAt: 'Tanggal_diupdate'
    }
);

export default user;

(async()=>{
    await db.sync();})();