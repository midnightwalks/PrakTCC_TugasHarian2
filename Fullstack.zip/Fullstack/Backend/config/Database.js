import {Sequelize} from "sequelize";

const db = new Sequelize('hrd','root','inipassword',{
    host: '35.238.30.160',
    dialect: 'mysql'
})

export default db;