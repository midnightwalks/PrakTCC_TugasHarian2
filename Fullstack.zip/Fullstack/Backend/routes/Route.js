import express from "express";
import { createUser, getUsers, updateUser, deleteUser } from "../controller/UserController.js";

const router = express.Router();

//endpoint get semua data user
router.get('/users', getUsers);

//endpoint create data user
router.post('/tambah-user', createUser);


//endpoint update data user
router.put("/edit-user/:id", updateUser);

//endpoint delete data user
router.delete("/delete-user/:id", deleteUser);


export default router;